# Routing Eval Results

- Mode: heuristic
- Passed: 10/10
- Failed: 0
- Pass rate: 100.00%
- By mode: {'heuristic': 10}

## Per Query

### creator-explicit — PASS
- Prompt: 幫我建立一個新的 skill，用來整理客服對話並輸出 FAQ 草稿。
- Expected: skill-creator
- Predicted: skill-creator
- Confidence: high
- Mode used: heuristic
- Why: highest score: 5 (gap=5)
- Scores:
  - skill-creator: 5 (matched keyword '建立' (+4); matched keyword '新' (+1))
  - skill-description-optimizer: 0 (no strong match)
  - skill-evaluator: 0 (no strong match)

### creator-restructure — PASS
- Prompt: 這個 SKILL.md 太肥了，幫我拆邊界並重整 references 跟 scripts。
- Expected: skill-creator
- Predicted: skill-creator
- Confidence: high
- Mode used: heuristic
- Why: highest score: 20 (gap=24)
- Scores:
  - skill-creator: 20 (description overlap: md, references, scripts (+6); matched keyword '邊界' (+4); matched keyword 'references' (+3); matched keyword 'scripts' (+3); matched keyword 'skill.md' (+4))
  - skill-description-optimizer: -4 (negative hint 'references' (-2); negative hint 'scripts' (-2))
  - skill-evaluator: -4 (negative hint 'references' (-2); negative hint 'scripts' (-2))

### evaluator-explicit — PASS
- Prompt: 幫我驗證這個 skill 跟 baseline 比起來有沒有比較好，順便設計 benchmark。
- Expected: skill-evaluator
- Predicted: skill-evaluator
- Confidence: high
- Mode used: heuristic
- Why: highest score: 21 (gap=19)
- Scores:
  - skill-evaluator: 21 (description overlap: baseline, benchmark (+4); matched keyword 'benchmark' (+5); matched keyword 'baseline' (+5); matched keyword '驗證' (+4); matched keyword '比較' (+3))
  - skill-description-optimizer: 2 (description overlap: benchmark (+2))
  - skill-creator: -2 (description overlap: benchmark (+2); negative hint 'benchmark' (-2); negative hint 'baseline' (-2))

### evaluator-blind — PASS
- Prompt: 我有兩組 skill 輸出，幫我做 blind comparison，並找出 fail cluster。
- Expected: skill-evaluator
- Predicted: skill-evaluator
- Confidence: high
- Mode used: heuristic
- Why: highest score: 17 (gap=15)
- Scores:
  - skill-evaluator: 17 (description overlap: blind (+2); matched keyword 'blind' (+5); matched keyword 'comparison' (+4); matched keyword 'fail' (+2); matched keyword 'cluster' (+4))
  - skill-creator: 2 (description overlap: blind, comparison (+4); negative hint 'blind' (-2))
  - skill-description-optimizer: -2 (negative hint 'blind comparison' (-2))

### optimizer-explicit — PASS
- Prompt: 這個 skill 的 description 很容易誤觸發，幫我優化 frontmatter 並做 held-out trigger 測試。
- Expected: skill-description-optimizer
- Predicted: skill-description-optimizer
- Confidence: high
- Mode used: heuristic
- Why: highest score: 32 (gap=30)
- Scores:
  - skill-description-optimizer: 32 (description overlap: description, frontmatter, held-out, trigger (+8); matched keyword 'description' (+5); matched keyword 'frontmatter' (+5); matched keyword 'trigger' (+5); matched keyword 'held-out' (+4); matched keyword '誤觸發' (+5))
  - skill-creator: 2 (description overlap: frontmatter (+2))
  - skill-evaluator: 2 (description overlap: description, frontmatter (+4); negative hint 'frontmatter' (-2))

### optimizer-fnfp — PASS
- Prompt: 幫我降低這個 skill 的 false positive 跟 false negative，專心調 description 就好。
- Expected: skill-description-optimizer
- Predicted: skill-description-optimizer
- Confidence: high
- Mode used: heuristic
- Why: highest score: 19 (gap=17)
- Scores:
  - skill-description-optimizer: 19 (description overlap: description, false (+4); matched keyword 'description' (+5); matched keyword 'false positive' (+5); matched keyword 'false negative' (+5))
  - skill-evaluator: 2 (description overlap: description (+2))
  - skill-creator: -2 (negative hint 'false' (-2))

### negative-general-summary — PASS
- Prompt: 幫我總結這個 repo 的資料夾結構和技術棧。
- Expected: none
- Predicted: none
- Confidence: low
- Mode used: heuristic
- Why: top score below threshold (2 < 4)
- Scores:
  - skill-creator: 2 (matched keyword '資料夾' (+2))
  - skill-description-optimizer: 0 (no strong match)
  - skill-evaluator: 0 (no strong match)

### negative-generic-prompting — PASS
- Prompt: 幫我寫一段比較有說服力的產品文案。
- Expected: none
- Predicted: none
- Confidence: low
- Mode used: heuristic
- Why: top score below threshold (3 < 4)
- Scores:
  - skill-evaluator: 3 (matched keyword '比較' (+3))
  - skill-creator: 0 (no strong match)
  - skill-description-optimizer: 0 (no strong match)

### boundary-creator-vs-evaluator — PASS
- Prompt: 這個 skill 已經寫好了，現在我要 assertions、rubric 跟 regression tracking。
- Expected: skill-evaluator
- Predicted: skill-evaluator
- Confidence: high
- Mode used: heuristic
- Why: highest score: 25 (gap=25)
- Scores:
  - skill-evaluator: 25 (description overlap: assertions, regression, tracking (+6); matched keyword 'assertions' (+4); matched keyword 'assertion' (+4); matched keyword 'rubric' (+4); matched keyword 'regression' (+5); matched keyword 'tracking' (+2))
  - skill-description-optimizer: 0 (no strong match)
  - skill-creator: -2 (negative hint 'rubric' (-2))

### boundary-creator-vs-optimizer — PASS
- Prompt: 不要改 skill 內容，只改 description，讓它比較不會亂觸發。
- Expected: skill-description-optimizer
- Predicted: skill-description-optimizer
- Confidence: medium
- Mode used: heuristic
- Why: highest score: 7 (gap=2)
- Scores:
  - skill-description-optimizer: 7 (description overlap: description (+2); matched keyword 'description' (+5))
  - skill-evaluator: 5 (description overlap: description (+2); matched keyword '比較' (+3))
  - skill-creator: 0 (no strong match)
