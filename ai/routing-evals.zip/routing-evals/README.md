# cross-skill routing evals

這裡放拆分後三個 skill 的 routing 測試。

目標：
- 該觸發的 skill 要被觸發
- 相鄰 skill 不要誤觸發
- 拆分後的 description 邊界要穩定

建議每次修改以下任一項後都重跑：
- 三個 skill 的 `SKILL.md`
- `shared/` 內影響 routing 的 schema / templates
- description 相關腳本
