#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SKILLS = {
    "skill-creator": ROOT / "skill-creator" / "SKILL.md",
    "skill-evaluator": ROOT / "skill-evaluator" / "SKILL.md",
    "skill-description-optimizer": ROOT / "skill-description-optimizer" / "SKILL.md",
}
QUERIES = Path(__file__).resolve().parent / "queries.jsonl"
RESULTS_JSON = Path(__file__).resolve().parent / "routing-results.json"
RESULTS_MD = Path(__file__).resolve().parent / "routing-results.md"

STOPWORDS = {
    "the", "a", "an", "and", "or", "to", "of", "for", "when", "this", "that",
    "it", "is", "are", "be", "with", "use", "used", "skill", "user", "wants",
    "want", "asks", "task", "especially", "only", "from", "into", "than",
    "比較", "這個", "幫我", "不要", "只", "要", "做", "一個", "可以", "用", "把",
    "the", "for", "not", "use", "this", "skill", "when", "user", "asks", "especially",
}

PINNED_KEYWORDS = {
    "skill-creator": {
        "建立": 4, "新": 1, "重構": 4, "重寫": 3, "邊界": 4, "資料夾": 2,
        "references": 3, "scripts": 3, "骨架": 4, "skill.md": 4, "authoring": 4,
        "restructure": 4, "create": 2, "new reusable skill": 5, "folder layout": 4,
        "初始": 2, "scaffold": 4,
    },
    "skill-evaluator": {
        "benchmark": 5, "baseline": 5, "assertions": 4, "assertion": 4, "rubric": 4,
        "blind": 5, "comparison": 4, "compare": 4, "fail": 2, "cluster": 4,
        "regression": 5, "eval": 4, "驗證": 4, "比較": 3, "盲測": 5,
        "benchmark summaries": 4, "tracking": 2,
    },
    "skill-description-optimizer": {
        "description": 5, "frontmatter": 5, "trigger": 5, "held-out": 4,
        "false positive": 5, "false negative": 5, "誤觸發": 5, "漏觸發": 5,
        "改寫": 3, "query": 2, "queries": 2, "rewrite": 2, "trigger metrics": 4,
        "description rewrites": 4,
    },
}

NEGATIVE_HINTS = {
    "skill-creator": {"benchmark", "baseline", "blind", "rubric", "false", "trigger metrics"},
    "skill-evaluator": {"frontmatter", "description rewrites", "folder layout", "references", "scripts", "boundary design"},
    "skill-description-optimizer": {"blind comparison", "benchmark summaries", "folder layout", "references", "scripts", "authoring"},
}


@dataclass
class SkillInfo:
    name: str
    description: str
    keywords: set[str]


def parse_frontmatter_description(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        raise ValueError(f"Missing frontmatter: {path}")
    m = re.match(r"^---\n(.*?)\n---", text, re.DOTALL)
    if not m:
        raise ValueError(f"Invalid frontmatter: {path}")
    fm = m.group(1)
    lines = fm.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("description:"):
            value = line.split(":", 1)[1].strip()
            if value in {"|", ">", "|-", ">-"}:
                parts = []
                i += 1
                while i < len(lines) and (lines[i].startswith("  ") or lines[i].startswith("\t")):
                    parts.append(lines[i].strip())
                    i += 1
                return " ".join(parts).strip()
            return value.strip().strip('"').strip("'")
        i += 1
    raise ValueError(f"Missing description in {path}")


def tokenize(text: str) -> list[str]:
    parts = re.split(r"[^A-Za-z0-9\-\u4e00-\u9fff]+", text.lower())
    return [p for p in parts if p and p not in STOPWORDS and len(p) > 1]


def load_skills() -> dict[str, SkillInfo]:
    out: dict[str, SkillInfo] = {}
    for name, path in SKILLS.items():
        description = parse_frontmatter_description(path)
        keywords = set(tokenize(description))
        keywords.add(name.lower())
        out[name] = SkillInfo(name=name, description=description, keywords=keywords)
    return out


def load_queries() -> list[dict[str, Any]]:
    rows = []
    for line in QUERIES.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def score_prompt(prompt: str, skill: SkillInfo) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    prompt_l = prompt.lower()
    prompt_tokens = set(tokenize(prompt))

    overlap = sorted(prompt_tokens & skill.keywords)
    if overlap:
        add = len(overlap) * 2
        score += add
        reasons.append(f"description overlap: {', '.join(overlap[:8])} (+{add})")

    for phrase, weight in PINNED_KEYWORDS.get(skill.name, {}).items():
        if phrase.lower() in prompt_l:
            score += weight
            reasons.append(f"matched keyword '{phrase}' (+{weight})")

    for phrase in NEGATIVE_HINTS.get(skill.name, set()):
        if phrase.lower() in prompt_l:
            score -= 2
            reasons.append(f"negative hint '{phrase}' (-2)")

    return score, reasons


def route_prompt_heuristic(prompt: str, skills: dict[str, SkillInfo], threshold: int = 4) -> dict[str, Any]:
    scored = []
    for name, skill in skills.items():
        score, reasons = score_prompt(prompt, skill)
        scored.append({"skill": name, "score": score, "reasons": reasons})
    scored.sort(key=lambda x: (-x["score"], x["skill"]))

    top = scored[0]
    second = scored[1]
    if top["score"] < threshold:
        predicted = "none"
        why = f"top score below threshold ({top['score']} < {threshold})"
        confidence = "low"
    elif top["score"] == second["score"] and top["score"] > 0:
        predicted = "ambiguous"
        why = f"tie between {top['skill']} and {second['skill']}"
        confidence = "low"
    else:
        predicted = top["skill"]
        gap = top["score"] - second["score"]
        confidence = "high" if gap >= 4 else "medium" if gap >= 2 else "low"
        why = f"highest score: {top['score']} (gap={gap})"

    return {
        "predicted_skill": predicted,
        "why": why,
        "scores": scored,
        "confidence": confidence,
        "mode_used": "heuristic",
    }


def build_llm_prompt(prompt: str, skills: dict[str, SkillInfo]) -> str:
    blocks = []
    for name, skill in skills.items():
        blocks.append(f"- {name}: {skill.description}")
    joined = "\n".join(blocks)
    return f"""You are routing a user request to one of these split skills.

Available skills:
{joined}

User prompt:
{prompt}

Choose exactly one of:
- skill-creator
- skill-evaluator
- skill-description-optimizer
- none
- ambiguous

Return ONLY valid JSON with this schema:
{{
  \"predicted_skill\": \"...\",
  \"why\": \"short reason\",
  \"confidence\": \"high|medium|low\"
}}
"""


def route_prompt_llm(prompt: str, skills: dict[str, SkillInfo], model: str | None = None) -> dict[str, Any]:
    if shutil.which("claude") is None:
        raise RuntimeError("claude CLI not found")

    cmd = ["claude", "-p", "--output-format", "text"]
    if model:
        cmd.extend(["--model", model])
    llm_prompt = build_llm_prompt(prompt, skills)
    env = None
    result = subprocess.run(cmd, input=llm_prompt, text=True, capture_output=True, env=env, timeout=180)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"claude exited {result.returncode}")

    text = result.stdout.strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    raw = match.group(0) if match else text
    payload = json.loads(raw)
    predicted = payload.get("predicted_skill", "ambiguous")
    if predicted not in {"skill-creator", "skill-evaluator", "skill-description-optimizer", "none", "ambiguous"}:
        predicted = "ambiguous"
    return {
        "predicted_skill": predicted,
        "why": payload.get("why", "llm judge"),
        "confidence": payload.get("confidence", "medium"),
        "scores": [],
        "mode_used": "llm",
        "llm_raw": text,
    }


def route_prompt(prompt: str, skills: dict[str, SkillInfo], mode: str, model: str | None, fallback_to_heuristic: bool) -> dict[str, Any]:
    heuristic = route_prompt_heuristic(prompt, skills)
    if mode == "heuristic":
        return heuristic

    if mode == "llm":
        try:
            return route_prompt_llm(prompt, skills, model=model)
        except Exception as exc:
            if not fallback_to_heuristic:
                raise
            fallback = dict(heuristic)
            fallback["why"] = f"LLM unavailable, fallback to heuristic: {exc}"
            fallback["mode_used"] = "heuristic-fallback"
            return fallback

    # hybrid
    top = heuristic["scores"][0]
    second = heuristic["scores"][1]
    close_call = heuristic["predicted_skill"] in {"none", "ambiguous"} or abs(top["score"] - second["score"]) <= 2
    if not close_call:
        hybrid = dict(heuristic)
        hybrid["mode_used"] = "hybrid-heuristic"
        return hybrid
    try:
        llm = route_prompt_llm(prompt, skills, model=model)
        llm["scores"] = heuristic["scores"]
        llm["why"] = f"hybrid chose llm on close call; {llm['why']}"
        llm["mode_used"] = "hybrid-llm"
        return llm
    except Exception as exc:
        if not fallback_to_heuristic:
            raise
        fallback = dict(heuristic)
        fallback["why"] = f"hybrid fallback to heuristic: {exc}"
        fallback["mode_used"] = "hybrid-fallback"
        return fallback


def summarize(results: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(results)
    passed = sum(1 for r in results if r["passed"])
    failed = total - passed
    by_skill: dict[str, dict[str, int]] = {}
    by_mode: dict[str, int] = {}
    for r in results:
        expected = r["expected_skill"]
        by_skill.setdefault(expected, {"passed": 0, "failed": 0})
        by_skill[expected]["passed" if r["passed"] else "failed"] += 1
        by_mode[r["mode_used"]] = by_mode.get(r["mode_used"], 0) + 1
    return {
        "passed": passed,
        "failed": failed,
        "total": total,
        "pass_rate": round(passed / total, 4) if total else 0.0,
        "by_expected_skill": by_skill,
        "by_mode": by_mode,
    }


def compare_with_previous(current_results: list[dict[str, Any]], compare_to: Path | None) -> dict[str, Any] | None:
    if not compare_to or not compare_to.exists():
        return None
    previous = json.loads(compare_to.read_text(encoding="utf-8"))
    prev_by_id = {r["id"]: r for r in previous.get("results", [])}
    changed = []
    for item in current_results:
        old = prev_by_id.get(item["id"])
        if not old:
            continue
        if old.get("predicted_skill") != item.get("predicted_skill") or old.get("passed") != item.get("passed"):
            changed.append({
                "id": item["id"],
                "old_predicted": old.get("predicted_skill"),
                "new_predicted": item.get("predicted_skill"),
                "old_passed": old.get("passed"),
                "new_passed": item.get("passed"),
            })
    return {
        "compare_to": str(compare_to),
        "changed_queries": changed,
        "changed_count": len(changed),
    }


def write_markdown(results: list[dict[str, Any]], summary: dict[str, Any], comparison: dict[str, Any] | None, mode: str) -> None:
    lines = [
        "# Routing Eval Results",
        "",
        f"- Mode: {mode}",
        f"- Passed: {summary['passed']}/{summary['total']}",
        f"- Failed: {summary['failed']}",
        f"- Pass rate: {summary['pass_rate']:.2%}",
        f"- By mode: {summary['by_mode']}",
        "",
    ]
    if comparison:
        lines.extend([
            "## Regression Compare",
            f"- Compared to: {comparison['compare_to']}",
            f"- Changed queries: {comparison['changed_count']}",
            "",
        ])
    lines.extend(["## Per Query", ""])
    for r in results:
        mark = "PASS" if r["passed"] else "FAIL"
        lines.append(f"### {r['id']} — {mark}")
        lines.append(f"- Prompt: {r['prompt']}")
        lines.append(f"- Expected: {r['expected_skill']}")
        lines.append(f"- Predicted: {r['predicted_skill']}")
        lines.append(f"- Confidence: {r.get('confidence', 'n/a')}")
        lines.append(f"- Mode used: {r['mode_used']}")
        lines.append(f"- Why: {r['why']}")
        if r.get("scores"):
            lines.append("- Scores:")
            for s in r["scores"]:
                lines.append(f"  - {s['skill']}: {s['score']} ({'; '.join(s['reasons']) if s['reasons'] else 'no strong match'})")
        lines.append("")
    RESULTS_MD.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run cross-skill routing evals")
    parser.add_argument("--mode", choices=["heuristic", "hybrid", "llm"], default="hybrid")
    parser.add_argument("--model", default=None, help="Model name for llm/hybrid mode via claude -p")
    parser.add_argument("--compare-to", default=None, help="Previous routing-results.json to compare against")
    parser.add_argument("--no-fallback", action="store_true", help="Do not fall back to heuristic if llm mode fails")
    args = parser.parse_args()

    skills = load_skills()
    queries = load_queries()
    results = []
    for row in queries:
        routed = route_prompt(
            row["prompt"],
            skills,
            mode=args.mode,
            model=args.model,
            fallback_to_heuristic=not args.no_fallback,
        )
        result = {
            **row,
            **routed,
            "passed": row["expected_skill"] == routed["predicted_skill"],
        }
        results.append(result)

    summary = summarize(results)
    comparison = compare_with_previous(results, Path(args.compare_to) if args.compare_to else None)
    payload = {
        "version": 2,
        "mode": args.mode,
        "skills": {k: {"description": v.description} for k, v in skills.items()},
        "summary": summary,
        "comparison": comparison,
        "results": results,
    }
    RESULTS_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    write_markdown(results, summary, comparison, args.mode)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if comparison:
        print(json.dumps(comparison, ensure_ascii=False, indent=2))
    print(f"Wrote: {RESULTS_JSON}")
    print(f"Wrote: {RESULTS_MD}")


if __name__ == "__main__":
    main()
