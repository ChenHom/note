# run_routing_eval.py v2 完成說明

## 這次完成了什麼

已將 `routing-evals/run_routing_eval.py` 升級為 v2，新增：

- `--mode heuristic|hybrid|llm`
- `hybrid` 模式：先跑 heuristic，close call 再交給 LLM judge
- `llm` 模式：全程由 LLM judge 判定
- `--compare-to`：可與上一版 `routing-results.json` 做回歸比較
- `--no-fallback`：可禁止 LLM 失敗時退回 heuristic
- 更完整的輸出欄位：
  - `confidence`
  - `mode_used`
  - `why`
  - `comparison`
  - `by_mode`

## 目前定位

這支工具是 cross-skill routing boundary evaluator，用來驗證：

- 該觸發的 skill 有沒有觸發對
- 相鄰 skill 有沒有誤觸發
- negative control 能不能保持安靜

## 目前限制

- `llm` / `hybrid` 依賴本機 `claude` CLI
- 若無 `claude` CLI，預設會 fallback 到 heuristic
- 目前是 routing judge，不是完整 runtime trace replay

## 產出檔案

- `routing-results.json`
- `routing-results.md`

## 後續可做

- 接真正的 trigger trace / runtime events
- 接 regression dashboard
- 納入 smoke test pipeline
