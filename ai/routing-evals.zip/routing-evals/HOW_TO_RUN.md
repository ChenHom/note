# How to run cross-skill routing evals

## v2 capabilities

`run_routing_eval.py` 現在支援三種模式：

- `heuristic`：純規則式 / 關鍵詞加權
- `hybrid`：先跑 heuristic，遇到 close call / low confidence 再用 LLM judge
- `llm`：全部交給 LLM judge

預設是：`hybrid`

## Basic usage

### 1. Heuristic only

```bash
python routing-evals/run_routing_eval.py --mode heuristic
```

### 2. Hybrid (default)

```bash
python routing-evals/run_routing_eval.py
```

### 3. Pure LLM judge

```bash
python routing-evals/run_routing_eval.py --mode llm
```

### 4. Compare with previous results

```bash
python routing-evals/run_routing_eval.py \
  --mode hybrid \
  --compare-to routing-evals/routing-results.previous.json
```

## Outputs

會產出：

- `routing-evals/routing-results.json`
- `routing-evals/routing-results.md`

內容包含：
- summary
- by_expected_skill
- by_mode
- per-query prediction
- confidence
- why / reasons
- regression compare（如果有提供 `--compare-to`）

## Notes

- 若 `hybrid` / `llm` 模式找不到 `claude` CLI，預設會 fallback 回 heuristic。
- 若不想 fallback，可加 `--no-fallback`。
- 這支是 routing boundary evaluator，不是完整 benchmark runner。
